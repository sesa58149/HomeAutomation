typedef char Int8;
typedef char        Int8;
typedef unsigned char   Uint8;
typedef signed char     Sint8;

typedef unsigned short  Uint16;
typedef signed short    Sint16;

typedef unsigned long   Uint32;
typedef signed long     Sint32; 
typedef int BOOL;