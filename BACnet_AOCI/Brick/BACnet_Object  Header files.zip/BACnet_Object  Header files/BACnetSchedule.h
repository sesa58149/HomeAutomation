#ifndef BACNETSCHEDULE_H__
#define BACNETSCHEDULE_H__

/**   @file BACnetSchedule.h
*     @brief Header file for BACnetSchedule.c i.e. definition of Schedule Object Data Structures for Bacnet.
*     <TABLE>
*     <TR> <TD> Copyright </TD> </TR>
*     <TR>
*     <TD> Schneider Automation, Inc., 1 High Street, North
*     Andover, MA 01845, USA Copyright (c) 2009 - All rights
*     reserved. </TD>
*     </TR>
*     <TR>
*     <TD> No part of this document may be reproduced in any
*       form without the express written consent of Schneider
*       Electric, Inc. </TD>
*     </TR>
*     </TABLE>
* 
*     @par
*     @author Ted Han, Pawan Modi, Ron Naismith
*     @par HISTORY
*     
*     <TABLE>
*     <TR>
*     <TD>Ted Han, Pawan Modi</TD>	<TD>5-Jul-2009</TD> <TD>Created </TD>
*		</TR>
*		<TR>
*     <TD>Ron Naismith</TD>	<TD>5-Aug-2009</TD>	<TD>Added Doxygen Header </TD>
*     </TR>
*     </TABLE>
*/


/******************************************************************************/
/** include files **/
#include "trTypes.h"
#include "BACnetAppDefines.h"
#include "BACnetTimeStamp.h"
#include "BACnetCalender.h"


  /**
* @typedef BACnetDailySchedule
* @brief BACnetDailySchedule type Data Structure
*/
 typedef struct
 {
  TR_BACnetTimeValue timeValue[MAX_DAILY_TIME_VALUES];
 }BACnetDailySchedule;

 /**
* @typedef BACnetSpecialEvent
* @brief BACnetSpecialEvent type Data Structure
*/
typedef struct
 {
    Uint8  periodType;
    union Period
	{
		Uint32 calendarReference;
		BACnetCalenderEntry calendarEntry;
   };
    TR_BACnetTimeValue timeValue[MAX_SPECIAL_EVENT_TIME_VALUES];
    Uint16 EventPriority;
 }BACnetSpecialEvent;

 /**
* @typedef DeviceObjectPropertyReference
* @brief DeviceObjectPropertyReference type Data Structure
*/
typedef struct
 {
	Uint32 object_id;
	Uint32 property_id;
   Uint32 Property_array_index;
   Uint32 device_id;
 }BACnetDeviceObjectPropertyReference;

/**
* @typedef BACnetSchedule
* @brief BACnet Schedule Object Data Structure
*/
typedef struct
{
   Uint32 object_id;
	Int8  object_name[MAX_STR_LEN];
	Uint8 object_type;
   Uint32 present_value;
	Int8 description[MAX_STR_LEN];
	TR_BACnetDateRange effective_period;
	BACnetDailySchedule weekly_schedule[NO_DAYS_IN_THE_WEEK];
	BACnetSpecialEvent exception_schedule[MAX_NO_OF_EXCEPTIONS_LOGGED];
	Uint32 schedule_default;
   BACnetDeviceObjectPropertyReference listofObjectPropertyReference[MAX_NO_OF_REFERENCES];
	Uint16 priority_for_writing;
	Uint8 status_flags;
	Uint8 reliability;
	BOOL out_of_service;
	int8 ProfileName[MAX_STR_LEN];
}BACnetSchedule_Flash;



#endif //BACNETSCHEDULE_H__
