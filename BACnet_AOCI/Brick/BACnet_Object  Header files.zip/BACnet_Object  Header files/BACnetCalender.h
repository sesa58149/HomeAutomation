#ifndef BACNETCALENDER_H__
#define BACNETCALENDER_H__

/**   @file BACnetCalender.h
*     @brief Header file for BACnetCalender.c i.e. definition of Schedule Object Data Structures for Bacnet.
*     <TABLE>
*     <TR> <TD> Copyright </TD> </TR>
*     <TR>
*     <TD> Schneider Automation, Inc., 1 High Street, North
*     Andover, MA 01845, USA Copyright (c) 2009 - All rights
*     reserved. </TD>
*     </TR>
*     <TR>
*     <TD> No part of this document may be reproduced in any
*       form without the express written consent of Schneider
*       Electric, Inc. </TD>
*     </TR>
*     </TABLE>
* 
*     @par
*     @author Ted Han, Pawan Modi, Ron Naismith
*     @par HISTORY
*     
*     <TABLE>
*     <TR>
*     <TD>Ted Han, Pawan Modi</TD>	<TD>5-Jul-2009</TD> <TD>Created </TD>
*		</TR>
*		<TR>
*     <TD>Ron Naismith</TD>	<TD>5-Aug-2009</TD>	<TD>Added Doxygen Header </TD>
*     </TR>
*     </TABLE>
*/


/******************************************************************************/
/** include files **/
#include "trTypes.h"
#include "BACnetAppDefines.h"
#include "BACnetTimeStamp.h"


/**
* @typedef BACnetWeekNday
* @brief BACnet week and Day type Data Structure
*/
 typedef struct
 {
	Int8 day_of_week;
	Int8 week_of_month;
	Int8 month_of_year;
 }BACnetWeekNday;

 /**
* @typedef BACnetCalenderEntryType
* @brief BACnet Calender entry type enum
*/
 typedef enum
 {
    BACNET_CALENDER_ENTRY_DATE=0,
    BACNET_CALENDER_ENTRY_DATE_RANGE,
    BACNET_CALENDER_ENTRY_WEEK_N_DAY,
    BACNET_CALENDER_ENTRY_INVALID
 }BACnetCalenderEntryType;

/**
* @typedef BACnetCalenderEntry
* @brief BACnet Calender Entry type Data Structure
*/
 typedef struct
 {
   BACnetCalenderEntryType type;
   union Entry {
    TR_BACnetDate date;
    TR_BACnetDateRange dateRange;
    BACnetWeekNday  weekNday;
    };
 }BACnetCalenderEntry;

/**
* @typedef BACnetCalender
* @brief BACnet Calender Object Data Structure
*/
 typedef struct
 {
   Uint32 object_id;
	Int8  object_name[MAX_STR_LEN];
	Uint8 object_type;
   Uint32 present_value;
   BACnetCalenderEntry date_list[MAX_BACNET_CALANDER_ENTRY];
   int8 ProfileName[MAX_STR_LEN];
 }BACnetCalender_Flash;

#endif //BACNETCALENDER_H__
